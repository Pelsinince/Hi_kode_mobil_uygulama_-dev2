//Soru 1:
void main() {
  List<int> sayilar = [7, 2, 5, 1, 6];
  print(toplamListe(sayilar));
}

int toplamListe(List<int> liste) {
  int toplam = 0;
  for (int sayi = 0; sayi < liste.length; sayi++) {
    toplam += liste[sayi];
  }
  return toplam;
}

/*Soru 2:
void main() {
  List<int> sayilar = [1, 2, 7, 4, 13, 6, 15, 8, 9];
  print(tekSayilariFiltrelemek(sayilar));
}


List<int> tekSayilariFiltrelemek(List<int> liste) {
  List<int> tek = [];
  for (int sayi in liste) {
    if (sayi % 2 != 0) {
      tek.add(sayi);
    }
  }
  return tek;
}




Soru 3:
void main() {
  List<String> harfler = ['p', 'l', 'ş', 'n'];
  print(listeCevir(harfler)); 
}


List listeCevir(List liste) {
  List tersListeleme = [];
  for (int i = liste.length - 1; i >= 0; i--) {
    tersListeleme.add(liste[i]);
  }
  return tersListeleme;
}
*/
