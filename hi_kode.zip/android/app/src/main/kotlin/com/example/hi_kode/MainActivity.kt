package com.example.hi_kode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
